#!/bin/sh
[ $# -ne 3 ] && { 
 echo "Usage: sh 36c221be-6ab2-ef53-1589-fe16877914a8.sh  <数据库用户名> <端口号> <数据库密码>";
 exit 1;
}
# 获取当前路径

pathname=`pwd`



# 执行pl脚本
perl $pathname/36c221be-6ab2-ef53-1589-fe16877914a8.pl "${1}" "${2}" "${3}"
