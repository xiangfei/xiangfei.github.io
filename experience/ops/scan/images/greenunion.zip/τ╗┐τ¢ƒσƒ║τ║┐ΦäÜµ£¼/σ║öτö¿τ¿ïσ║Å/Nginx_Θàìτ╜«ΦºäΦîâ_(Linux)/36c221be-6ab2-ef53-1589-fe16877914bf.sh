#!/bin/sh
[ $# -ne 3 ] && { 
 echo "Usage: sh 36c221be-6ab2-ef53-1589-fe16877914bf.sh  <SU用户名> <SU用户密码> <Nginx安装目录(eg:/usr/local/nginx)>";
 exit 1;
}
# 获取当前路径

pathname=`pwd`



# 执行pl脚本
perl $pathname/36c221be-6ab2-ef53-1589-fe16877914bf.pl "${1}" "${2}" "${3}"
