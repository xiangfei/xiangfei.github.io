#!env perl
#Author: autoCreated
my $para_num = "3";
# 配置模板创建时间
my $template_time = "2018-01-19 10:37:26";
my %para;
@array_pre_flag = ();
@array_appendix_flag = ();

$para{Nginx_root_user} = $ARGV[0];
$para{Nginx_root_password} = $ARGV[1];
$para{Nginx_install_dir_linux} = $ARGV[2];

# 处理检查项中的执行命令

$pre_cmd{2175} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep -e \"access_log\\s*logs\\/access\\.log.*\"";
$pre_cmd{2344} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep \"log_format\"";
$pre_cmd{8899} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep -i \"limit_rate\"";
$pre_cmd{9415} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep -i \"location\\s*~\\*\\s*\\s*^\\.+\"";
$pre_cmd{10614} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf|grep -v ^[[:space:]]*#|grep error_page";
$pre_cmd{1164} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf | grep \"error_log\"";
$pre_cmd{4792} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep -i \"client_body_timeout\"";
$pre_cmd{4816} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep -i \"client_header_timeout\"";
$pre_cmd{7914} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep \"limit_conn\"";
$pre_cmd{7351} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep -i \"limit_zone\"";
$pre_cmd{11908} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep -v \"#\" | grep  \"server_tokens\" || echo server_tokens is not config";
$pre_cmd{3635} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep \"allow\"";
$pre_cmd{5580} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep -i \"keepalive_timeout\"";
$pre_cmd{6111} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep -i \"send_timeout\"";
$pre_cmd{3205} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep \"deny\"";

push(@array_pre_flag, 2175);
push(@array_pre_flag, 2344);
push(@array_pre_flag, 8899);
push(@array_pre_flag, 9415);
push(@array_pre_flag, 10614);
push(@array_pre_flag, 1164);
push(@array_pre_flag, 4792);
push(@array_pre_flag, 4816);
push(@array_pre_flag, 7914);
push(@array_pre_flag, 7351);
push(@array_pre_flag, 11908);
push(@array_pre_flag, 3635);
push(@array_pre_flag, 5580);
push(@array_pre_flag, 6111);
push(@array_pre_flag, 3205);

$pre_cmd1{2175} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep -e \"access_log\\s*logs\\/access\\.log.*\"";
$pre_cmd1{2344} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep \"log_format\"";
$pre_cmd1{8899} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep -i \"limit_rate\"";
$pre_cmd1{9415} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep -i \"location\\s*~\\*\\s*\\s*^\\.+\"";
$pre_cmd1{10614} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf|grep -v ^[[:space:]]*#|grep error_page";
$pre_cmd1{1164} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf | grep \"error_log\"";
$pre_cmd1{4792} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep -i \"client_body_timeout\"";
$pre_cmd1{4816} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep -i \"client_header_timeout\"";
$pre_cmd1{7914} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep \"limit_conn\"";
$pre_cmd1{7351} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep -i \"limit_zone\"";
$pre_cmd1{11908} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep -v \"#\" | grep  \"server_tokens\" || echo server_tokens is not config";
$pre_cmd1{3635} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep \"allow\"";
$pre_cmd1{5580} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep -i \"keepalive_timeout\"";
$pre_cmd1{6111} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep -i \"send_timeout\"";
$pre_cmd1{3205} = "cat $para{Nginx_install_dir_linux}/conf/nginx.conf  | grep \"deny\"";

# 处理附录检查项中的执行命令

$appendix_cmd{0} = "$para{Nginx_install_dir_linux}/sbin/nginx -v >/tmp/nginxversion 2>&1
cat /tmp/nginxversion";$appendix_cmd{1} = "$para{Nginx_install_dir_linux}/sbin/nginx -V";
push(@array_appendix_flag, 0);
push(@array_appendix_flag, 1);

$appendix_cmd1{0} = "$para{Nginx_install_dir_linux}/sbin/nginx -v >/tmp/nginxversion 2>&1
cat /tmp/nginxversion";$appendix_cmd1{1} = "$para{Nginx_install_dir_linux}/sbin/nginx -V";
# 获取操作系统信息函数
sub get_os_info{
 my %os_info = (
 "hostname"=>"","osname"=>"","osversion"=>"");
 $os_info{"hostname"} = `uname -n`;
 $os_info{"osname"} = `uname -s`;
 $os_info{"osversion"} = `uname -r`;
foreach (%os_info){   chomp;}
return %os_info;}

# 执行命令存入xml文件
sub add_item{
 my ($string, $flag, $command, $value)= @_;
 $string .= "\t\t".'<item flag="'.$flag.'">'."\n";
 $string .= "\t\t\t".'<cmd info="'.$date.'">'."\n";
 $string .= "\t\t\t<command><![CDATA[".$command."]]></command>\n";
 $string .= "\t\t\t<value><![CDATA[".$value."]]></value>\n";
 $string .= "\t\t\t</cmd>\n";
 $string .= "\t\t</item>\n";
return $string;}
 sub generate_xml{
 $ARGC = @ARGV;
if($ARGC lt 3){
 print qq{usag: 36c221be-6ab2-ef53-1589-fe16877914bf.pl  <SU用户名> <SU用户密码> <Nginx安装目录(eg:/usr/local/nginx)>};
exit;}
my %os_info = get_os_info();
 my $os_name = $os_info{"osname"};
 my $host_name = $os_info{"hostname"};
 my $os_version = $os_info{"osversion"};
 my $date = `date +%y-%m-%d`;
 chomp $date;
 my $ipaddr = "";
 if($os_name =~ /SunOS|AIX/i){
  $ipaddr = `ifconfig -a | awk '/inet.[0-9]/{print \$2}' | grep -v 127 | head -n 1`;
 }else{
  $ipaddr = `ifconfig | grep -oE 'inet[[:space:]]*(addr)?\.?([0-9]{1,3}\\.?){4}' | grep -v 127 | grep -oE '([0-9]{1,3}\\.?){4}' | head -n 1`;}
 chomp $ipaddr;
 my $xml_string = "";
 $xml_string .='<?xml version="1.0" encoding="UTF-8"?>'."\n";
 $xml_string .= '<result uuid= "'.'36c221be-6ab2-ef53-1589-fe16877914bf'.'" ip="'.$ipaddr.'" template_time= "2018-01-19 10:37:26'.'">'."\n";
 $xml_string .= "\t".'<initcmd>'."\n";
 $xml_string .= "\t\t".'<cmd info="'.$date.'">';
 $xml_string .= '</cmd>'."\n";
 $xml_string .= "\t\t\t".'<command><![CDATA[ ]]></command>'."\n";
 $xml_string .= "\t\t\t".'<value><![CDATA[ ]]></value>'."\n";
 $xml_string .= "\t".'</initcmd>'."\n";
 $xml_string .= "\t".'<security type="auto">'."\n";
 foreach $key (@array_pre_flag){
 $value = $pre_cmd{$key};
 $value_1 = $pre_cmd1{$key};
 my $tmp_result = `$value`;
 chomp $tmp_result;
 $tmp_result =~ s/>/&gt;/g;
 $xml_string = &add_item( $xml_string, $key, $value_1, $tmp_result );}
 $xml_string .= "\t</security>\n";
 $xml_string .= "\t".'<security type="display">'."\n";
 foreach $key (@array_appendix_flag){
 $value = $appendix_cmd{$key};
 $value_1 = $appendix_cmd1{$key};
 my $tmp_result = `$value`;
 chomp $tmp_result;
 $tmp_result =~ s/>/&gt;/g;
 $xml_string = &add_item( $xml_string, $key, $value_1, $tmp_result );}
 $xml_string .= "\t"."</security>"."\n";
 $xml_string .= "</result>"."\n";
 $xmlfile = $ipaddr."_"."36c221be-6ab2-ef53-1589-fe16877914bf"."_chk.xml";
 print $xmlfile."\n";
 open XML,">/tmp/".$xmlfile or die "Cannot create ip.xml:$!";
 print XML $xml_string;
 print "end write xml\n";
 print "DONE ALL\n";}
 generate_xml();
